package com.mycompany.stockvelapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
